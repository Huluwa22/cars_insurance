//入库记录列表参数类型
export type MaterialSendParm = {
    currentPage:number,
    pageSize:number,
    province:string,
    name:string,
    total:number,
    status:string,
    type:string
}
