//登录参数类型
export type LoginParm = {
    username:string,
    password:string,
    code:string
}
