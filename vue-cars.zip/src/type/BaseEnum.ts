export enum EditType{
    ADD = '0', //代表新增
    EDIT = '1' //代表编辑
}

//定义弹框的标题
export enum Title {
    ADD = '新增',
    EDIT = '编辑'
}
