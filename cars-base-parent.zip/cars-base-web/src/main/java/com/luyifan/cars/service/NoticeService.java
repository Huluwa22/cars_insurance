package com.luyifan.cars.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.luyifan.cars.model.entity.Notice;

public interface NoticeService extends IService<Notice> {
}