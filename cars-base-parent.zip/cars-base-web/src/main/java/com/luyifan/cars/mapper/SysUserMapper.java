package com.luyifan.cars.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.luyifan.cars.model.entity.SysUser;

public interface SysUserMapper extends BaseMapper<SysUser> {
}