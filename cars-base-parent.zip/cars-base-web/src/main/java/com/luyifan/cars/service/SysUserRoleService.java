package com.luyifan.cars.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.luyifan.cars.model.entity.SysUserRole;

public interface SysUserRoleService extends IService<SysUserRole> {
}