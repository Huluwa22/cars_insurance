package com.luyifan.cars.model.dto;

import lombok.Data;

@Data
public class InfoUpdateParm {
    private Long infoId;
    private Integer store;
}