package com.luyifan.cars.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.luyifan.cars.model.entity.SysUserRole;

public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {
}