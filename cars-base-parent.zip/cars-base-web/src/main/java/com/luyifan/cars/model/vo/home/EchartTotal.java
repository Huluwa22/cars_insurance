package com.luyifan.cars.model.vo.home;

import lombok.Data;

@Data
public class EchartTotal {
    private int insuranceTotal;
    private int categoryTotal;
    private int carInfoTotal;
}