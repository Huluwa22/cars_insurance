package com.luyifan.cars.model.vo.menu;

import lombok.Data;

@Data
public class SelectType {
    private Long value;
    private String label;
}