package com.luyifan.cars.model.vo.home;

import lombok.Data;

@Data
public class EchartsItem {
    private String name;
    private Integer value;



}
