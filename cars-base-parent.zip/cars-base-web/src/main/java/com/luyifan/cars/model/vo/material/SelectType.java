package com.luyifan.cars.model.vo.material;

import lombok.Data;

@Data
public class SelectType {
    private Long value;
    private String label;
}