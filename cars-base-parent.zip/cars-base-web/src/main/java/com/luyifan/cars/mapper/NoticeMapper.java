package com.luyifan.cars.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.luyifan.cars.model.entity.Notice;

public interface NoticeMapper extends BaseMapper<Notice> {
}